# VGG Image Annotator

VGG Image Annotator (VIA) is an open source project developed at the 
[Visual Geometry Group](http://www.robots.ox.ac.uk/~vgg/) and released under 
the BSD-2 clause license. This work is supported by EPSRC programme grant 
Seebibyte: Visual Search for the Era of Big Data ([EP/M013774/1](http://www.seebibyte.org/index.html)).

Visit the [VGG software page](http://www.robots.ox.ac.uk/~vgg/software/via/) and 
[source code repository](https://gitlab.com/vgg/via/) for more details.

## License
VIA is an open source project released under the 
[BSD-2 clause license](https://gitlab.com/vgg/via/blob/master/LICENSE).

## Author
[Abhishek Dutta](mailto:adutta@robots.ox.ac.uk)  
Aug. 31, 2016
