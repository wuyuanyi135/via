# Release Checklist

 * Enable google analytics javascript code in index.html
 * Ensure the via runs both on firefox and chrome
 * Remove `src="via.js"` as [pack_via.sh](pack_via.sh) script automatically inserts the javascript code.
 * Convert tab to spaces in the source (Emacs: M-x untabify)
