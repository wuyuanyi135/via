## 2.0
 * support for touch screen mobile interfaces

## 1.0
 * stable first public release
## 0.1b
 * basic image annotator for internal tests
